﻿
namespace TapSDK.Compliance.Model 
{
    internal class SubmitPaymentResponse : BaseResponse 
    {

    }
}
