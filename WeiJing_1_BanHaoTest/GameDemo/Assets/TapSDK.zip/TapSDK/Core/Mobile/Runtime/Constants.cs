namespace TapSDK.Core
{
    public static class Constants
    {
        public const string VersionKey = "Engine-Version";

        public const string PlatformKey = "Engine-Platform";
    }
}