﻿namespace TapSDK.UI
{
    public abstract class AbstractOpenPanelParameter
    {
        public virtual bool NeedConstantResolution => false;
    }
}