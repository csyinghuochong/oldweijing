﻿namespace TapSDK.Core
{
    public enum RegionType : int
    {
        CN = 0,
        IO = 1
    }
}