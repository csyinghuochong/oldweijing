﻿namespace TapSDK.Core {
    public enum TapLogLevel {
        Debug,
        Warn,
        Error,
    }
}
