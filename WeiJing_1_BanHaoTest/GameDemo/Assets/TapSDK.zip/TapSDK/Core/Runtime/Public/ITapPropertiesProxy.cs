﻿
namespace TapSDK.Core {
    public interface ITapPropertiesProxy {
        string GetProperties();
    }
}
