﻿namespace TapSDK.Core
{
    public enum TapLanguage
    {
        AUTO = 0,
        ZH_HANS = 1,
        EN = 2,
        ZH_HANT = 3,
        JA = 4,
        KO = 5,
        TH = 6,
        ID = 7,
        DE = 8,
        ES = 9,
        FR = 10,
        PT = 11,
        RU = 12,
        TR = 13,
        VI = 14
    }
}